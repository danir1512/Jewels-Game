#include "common.hpp"

bool g_gameOver{false};

SDL_Window* g_window{nullptr};

SDL_Renderer* g_renderer{nullptr};

#include "game.hpp"
#include <iostream>

int main() 
{
    Game game;
    return 0;
}
